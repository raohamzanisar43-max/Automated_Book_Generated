from fastapi import FastAPI
from contextlib import asynccontextmanager
from app.database import engine, Base
from app.routers import books

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize DB (in production, use Alembic)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    # Cleanup on shutdown
    await engine.dispose()

app = FastAPI(
    title="Automated Book Generation System",
    description="API for iteratively generating books with human-in-the-loop review.",
    version="1.0.0",
    lifespan=lifespan
)

app.include_router(books.router, prefix="/api/v1")

@app.get("/")
def read_root():
    return {"message": "Welcome to the Automated Book Generation API. Please refer to /docs."}
