from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Database Configuration
    supabase_url: Optional[str] = None
    supabase_key: Optional[str] = None
    supabase_service_key: Optional[str] = None
    database_url: str
    
    # AI Model Configuration
    openai_api_key: str
    openai_model: str = "gpt-4-turbo-preview"
    
    # Email Configuration
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_username: str
    smtp_password: str
    from_email: str
    
    # MS Teams Webhook
    teams_webhook_url: Optional[str] = None
    
    # Web Search Configuration
    serpapi_key: Optional[str] = None
    
    # Application Configuration
    secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # File Upload Configuration
    max_file_size: int = 10485760  # 10MB
    upload_dir: str = "uploads"
    
    class Config:
        env_file = ".env"


settings = Settings()
